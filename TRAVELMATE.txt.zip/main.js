// Travel Mate - Main JavaScript File
// Cart functionality and interactions

class TravelCart {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('travelCart')) || [];
        this.updateCartBadge();
    }

    addToCart(destination, price, image) {
        const existingItem = this.cart.find(item => item.destination === destination);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                destination: destination,
                price: price,
                image: image,
                quantity: 1,
                id: Date.now()
            });
        }
        
        this.saveCart();
        this.updateCartBadge();
        this.showNotification(`${destination} added to your bookings!`);
    }

    removeFromCart(id) {
        this.cart = this.cart.filter(item => item.id !== id);
        this.saveCart();
        this.updateCartBadge();
        this.renderCartItems();
        this.showNotification('Item removed from bookings');
    }

    updateQuantity(id, quantity) {
        const item = this.cart.find(item => item.id === id);
        if (item) {
            item.quantity = Math.max(1, quantity);
            this.saveCart();
            this.updateCartBadge();
            this.renderCartItems();
        }
    }

    getTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getItemCount() {
        return this.cart.reduce((count, item) => count + item.quantity, 0);
    }

    saveCart() {
        localStorage.setItem('travelCart', JSON.stringify(this.cart));
    }

    updateCartBadge() {
        const badge = document.querySelector('.cart-badge');
        const count = this.getItemCount();
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'block' : 'none';
        }
    }

    showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-check-circle"></i>
                <span>${message}</span>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #0b3d2e;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    renderCartItems() {
        const cartContainer = document.getElementById('cart-items');
        const cartTotal = document.getElementById('cart-total');
        const emptyCart = document.getElementById('empty-cart');
        
        if (!cartContainer) return;
        
        if (this.cart.length === 0) {
            cartContainer.style.display = 'none';
            if (emptyCart) emptyCart.style.display = 'block';
            if (cartTotal) cartTotal.textContent = 'Rs. 0';
            return;
        }
        
        if (emptyCart) emptyCart.style.display = 'none';
        cartContainer.style.display = 'block';
        
        cartContainer.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.destination}" class="cart-item-image">
                <div class="cart-item-details">
                    <h4>${item.destination}</h4>
                    <p class="price">Rs. ${item.price.toLocaleString()}</p>
                    <div class="quantity-controls">
                        <button onclick="cart.updateQuantity(${item.id}, ${item.quantity - 1})" class="qty-btn">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button onclick="cart.updateQuantity(${item.id}, ${item.quantity + 1})" class="qty-btn">+</button>
                    </div>
                </div>
                <button onclick="cart.removeFromCart(${item.id})" class="remove-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
        
        if (cartTotal) {
            cartTotal.textContent = `Rs. ${this.getTotal().toLocaleString()}`;
        }
    }

    clearCart() {
        this.cart = [];
        this.saveCart();
        this.updateCartBadge();
        this.renderCartItems();
    }
}

// Initialize cart
const cart = new TravelCart();

// Form validation and submission
function validateForm(formData) {
    const errors = [];
    
    if (!formData.name || formData.name.trim().length < 3) {
        errors.push('Name must be at least 3 characters long');
    }
    
    if (!formData.email || !isValidEmail(formData.email)) {
        errors.push('Please enter a valid email address');
    }
    
    if (!formData.phone || !isValidPhone(formData.phone)) {
        errors.push('Please enter a valid phone number');
    }
    
    return errors;
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

function handleContactForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
    
    const errors = validateForm(data);
    
    if (errors.length > 0) {
        showFormErrors(errors);
        return;
    }
    
    // Simulate form submission
    showLoadingState();
    
    setTimeout(() => {
        hideLoadingState();
        showSuccessMessage('Thank you for your message! We\'ll get back to you soon.');
        event.target.reset();
    }, 2000);
}

function handleBookingForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);
    
    const errors = validateForm(data);
    
    if (errors.length > 0) {
        showFormErrors(errors);
        return;
    }
    
    if (cart.cart.length === 0) {
        showFormErrors(['Please add some destinations to your booking first']);
        return;
    }
    
    showLoadingState();
    
    setTimeout(() => {
        hideLoadingState();
        showSuccessMessage('Booking confirmed! Thank you for choosing Travel Mate.');
        cart.clearCart();
        event.target.reset();
    }, 2000);
}

function showFormErrors(errors) {
    const errorContainer = document.getElementById('form-errors');
    if (errorContainer) {
        errorContainer.innerHTML = errors.map(error => `<p>${error}</p>`).join('');
        errorContainer.style.display = 'block';
    }
}

function showLoadingState() {
    const submitBtn = document.querySelector('.submit-btn');
    if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        submitBtn.disabled = true;
    }
}

function hideLoadingState() {
    const submitBtn = document.querySelector('.submit-btn');
    if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
        submitBtn.disabled = false;
    }
}

function showSuccessMessage(message) {
    cart.showNotification(message);
}

// Smooth scrolling for anchor links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Active navigation highlighting
function updateActiveNavigation() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

// Initialize page-specific functionality
function initPage() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    updateActiveNavigation();
    initSmoothScrolling();
    
    // Page-specific initialization
    switch (currentPage) {
        case 'orders.html':
        case 'bookings.html':
            cart.renderCartItems();
            break;
        case 'places.html':
            initPlacesPage();
            break;
    }
}

function initPlacesPage() {
    // Add hover effects to place cards
    const cards = document.querySelectorAll('.place-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initPage);

// Function to handle add to cart button clicks with visual feedback
function addToCartWithButton(button, destination, price, image) {
    // Add to cart
    cart.addToCart(destination, price, image);
    
    // Change button appearance
    button.classList.add('added');
    button.innerHTML = '<i class="fas fa-check"></i> Added to Cart';
    
    // Disable button temporarily
    button.disabled = true;
    
    // Re-enable after 2 seconds
    setTimeout(() => {
        button.disabled = false;
        button.classList.remove('added');
        button.innerHTML = '<i class="fas fa-cart-plus"></i> Add to Cart';
    }, 2000);
}

// Export for global access
window.cart = cart;
window.handleContactForm = handleContactForm;
window.handleBookingForm = handleBookingForm;
window.addToCartWithButton = addToCartWithButton;